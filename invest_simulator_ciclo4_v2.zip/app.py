import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sim.utils import (
    future_value_schedule,
    gbm_paths,
    portfolio_stats,
    run_guided_vs_chaotic_scenarios
)
st.set_page_config(page_title="Simulador de Investimentos — Ciclo 4", layout="wide")
st.title("📈 Simulador de Investimentos — Educação Financeira (Ciclo 4)")
st.markdown('''
Simulador educacional que conecta **lógica matemática** e **realidade financeira**.
- Juros compostos
- Carteira e risco (volatilidade, CAPM)
- Cenário guiado vs caótico
''')
st.sidebar.header("Configurações Gerais")
currency = st.sidebar.selectbox("Moeda", ["R$", "US$"], index=0)
risk_free = st.sidebar.number_input("Taxa livre de risco (a.a., %)", value=6.0, step=0.1)
tab1, tab2, tab3 = st.tabs(["🔢 Juros Compostos", "📊 Carteira & Risco", "🧭 Guiado vs. Caótico"])
with tab1:
    P0 = st.number_input("Capital inicial", value=1000.0)
    contrib = st.number_input("Aporte mensal", value=200.0)
    anos = st.number_input("Tempo (anos)", value=10)
    taxa = st.number_input("Taxa anual (%)", value=10.0)
    meses = int(anos * 12)
    taxa_mensal = (1 + taxa / 100) ** (1/12) - 1
    df = future_value_schedule(P0, contrib, taxa_mensal, meses)
    st.line_chart(df.set_index("Mês"))
with tab2:
    st.write("Simulação de carteira com Monte Carlo")
with tab3:
    st.write("Cenário Caótico vs Guiado")
