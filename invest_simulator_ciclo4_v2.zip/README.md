# Simulador de Investimentos — Ciclo 4

Protótipo em **Python + Streamlit** que ensina matemática financeira aplicada.